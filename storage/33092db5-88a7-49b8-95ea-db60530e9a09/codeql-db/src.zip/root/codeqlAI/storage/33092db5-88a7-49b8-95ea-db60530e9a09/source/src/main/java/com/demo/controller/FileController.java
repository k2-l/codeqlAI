package com.demo.controller;

import org.springframework.web.bind.annotation.*;

import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Files;
import java.nio.file.Paths;


@RestController
@RequestMapping("/api/file")
public class FileController {


    @GetMapping("/fetch")
    public String fetchUrl(@RequestParam String url) throws IOException {
        URLConnection connection = new URL(url).openConnection();
        BufferedReader reader = new BufferedReader(
            new InputStreamReader(connection.getInputStream())
        );
        StringBuilder content = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            content.append(line).append("\n");
        }
        return content.toString();
    }

    @PostMapping("/write")
    public String writeFile(@RequestParam String path, @RequestBody String content) {
        try {
            Files.write(Paths.get("/app/uploads/" + path), content.getBytes());
            return "File written successfully";
        } catch (IOException e) {
            return "Error: " + e.getMessage();
        }
    }

    @DeleteMapping("/delete")
    public String deleteFile(@RequestParam String path) {
        File file = new File("/app/uploads/" + path);
        if (file.delete()) {
            return "Deleted: " + path;
        }
        return "Failed to delete: " + path;
    }
}
