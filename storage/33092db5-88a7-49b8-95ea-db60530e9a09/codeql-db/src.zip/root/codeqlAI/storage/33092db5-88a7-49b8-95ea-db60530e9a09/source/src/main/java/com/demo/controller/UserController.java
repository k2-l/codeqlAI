package com.demo.controller;

import com.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.List;
import java.util.Map;


@RestController
@RequestMapping("/api/user")
public class UserController {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private UserService userService;


    @GetMapping("/search")
    public List<Map<String, Object>> searchUser(@RequestParam String name) {
        String sql = "SELECT * FROM users WHERE username = '" + name + "'";
        return jdbcTemplate.queryForList(sql);
    }

    @GetMapping("/list")
    public List<Map<String, Object>> listUsers(@RequestParam(defaultValue = "id") String orderBy) {
        String sql = "SELECT id, username, email FROM users ORDER BY " + orderBy;
        return jdbcTemplate.queryForList(sql);
    }

    @GetMapping("/greet")
    public void greetUser(@RequestParam String name, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");
        response.getWriter().write("<h1>Hello, " + name + "!</h1>");
    }

    @GetMapping("/file")
    public String readFile(@RequestParam String name) throws IOException {
        String basePath = "/app/files/";
        File file = new File(basePath + name);
        BufferedReader reader = new BufferedReader(new FileReader(file));
        StringBuilder content = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            content.append(line).append("\n");
        }
        reader.close();
        return content.toString();
    }

    @GetMapping("/ping")
    public String pingHost(@RequestParam String host) throws IOException {
        Runtime runtime = Runtime.getRuntime();
        Process process = runtime.exec("ping -c 1 " + host);
        BufferedReader reader = new BufferedReader(
            new InputStreamReader(process.getInputStream())
        );
        StringBuilder output = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            output.append(line).append("\n");
        }
        return output.toString();
    }

    @PostMapping("/deserialize")
    public String deserializeData(@RequestBody String base64Data) {
        try {
            byte[] data = java.util.Base64.getDecoder().decode(base64Data);
            ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(data));
            Object obj = ois.readObject();
            return "Deserialized: " + obj.toString();
        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }
}
